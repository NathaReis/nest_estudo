import { IsEmail, IsNotEmpty, IsNumber, MaxLength, MinLength } from "class-validator";

export class CreateUsuarioDto {
  @IsEmail()
  @IsNotEmpty()
  @MinLength(5)
  @MaxLength(100)
  readonly nome: string;
  @IsNotEmpty()
  @IsNumber()
  readonly senha: number;
}
